# S.G. Wedding Hub — Android Studio + Firebase

यह Android Studio source project आपके दिए हुए Android `google-services.json` और wedding hub HTML UI पर आधारित है। App display name **S.G. Wedding Hub** रखा गया है। इसमें Firebase Email/Password Admin sign-in, Firestore bookings और Firebase Storage gallery upload के लिए UI/code शामिल हैं।

## Android Studio
1. ZIP extract करें और Android Studio में `SGWeddingHub` folder खोलें।
2. JDK 17 और Android SDK Platform 35 रखें, फिर Gradle Sync करें।
3. Firebase Console में project `gsweddinghub-5a9e5` के Android app package `Gs.wedding.hub` की पुष्टि करें; ZIP में उसी package का `app/google-services.json` है।
4. Authentication में Email/Password enabled होना चाहिए और Admin user `mdsarjanalam5@gmail.com` Firebase Authentication में मौजूद होना चाहिए। Password source code में नहीं रखा गया है।
5. Firestore Database और Storage enabled होने चाहिए। Firebase Console में `firebase/firestore.rules` तथा `firebase/storage.rules` के नियम जाँचकर publish करें।
6. Run दबाकर Login, Booking और Gallery को test करें।

## GitHub Actions से APK
1. इस ZIP को repository root में `SG_Wedding_Hub_Firebase_Android_Studio.zip` नाम से upload/commit करें।
2. `extract_zip.yml` का content repository में `.github/workflows/android-build.yml` के रूप में रखें।
3. GitHub → Actions → **S.G. Wedding Hub Android Build** → Run workflow चुनें।
4. Build सफल होने पर run के नीचे `SG-Wedding-Hub-debug-APK` artifact डाउनलोड करें।

## Firebase note
HTML UI में Firebase Web SDK imports हैं, जबकि दिया गया JSON Android app config है। यदि Firebase Web SDK `appId` या web-app configuration error देता है, तो HTML-based Firebase calls को सही Web app config चाहिए या उन्हें native Android SDK bridge में बदलना होगा. केवल Android `google-services.json` Web `appId` प्रदान नहीं करता।

## Important
यह source ZIP है, verified APK नहीं। Build को GitHub Actions में चलाकर ही पता चलेगा कि कोई अतिरिक्त Gradle/compiler error है या नहीं। Rules को test किए बिना public production data न रखें।
